import type { DeliverySpeed, DeliveryStatus, RiderApplicationStatus, UserRole, VehicleType, WalletType } from "@/types/domain";

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          full_name: string | null;
          phone: string | null;
          email: string | null;
          role: UserRole;
          account_type?: string;
          avatar_url: string | null;
          default_zone: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name?: string | null;
          phone?: string | null;
          email?: string | null;
          role?: UserRole;
          avatar_url?: string | null;
          default_zone?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["users"]["Insert"]>;
      };
      rider_profiles: {
        Row: {
          id: string;
          user_id: string;
          application_status: RiderApplicationStatus;
          vehicle_type: VehicleType | null;
          plate_number: string | null;
          vehicle_color: string | null;
          operating_zone: string | null;
          bank_name: string | null;
          account_number: string | null;
          account_name: string | null;
          rating: number;
          acceptance_rate: number;
          level: "Bronze" | "Silver" | "Gold" | "Elite";
          online: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["rider_profiles"]["Row"]> & { user_id: string };
        Update: Partial<Database["public"]["Tables"]["rider_profiles"]["Row"]>;
      };
      deliveries: {
        Row: {
          id: string;
          delivery_code: string;
          customer_id: string;
          rider_id: string | null;
          pickup_address: string;
          pickup_contact: string | null;
          dropoff_address: string;
          dropoff_contact: string | null;
          parcel_type: string;
          vehicle_type: VehicleType;
          delivery_speed: DeliverySpeed;
          payment_method: "card" | "wallet" | "transfer";
          status: DeliveryStatus;
          price_ngn: number;
          distance_km: number;
          eta_minutes: number;
          picked_up_at: string | null;
          delivered_at: string | null;
          metadata: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["deliveries"]["Row"]> & {
          customer_id: string;
          pickup_address: string;
          dropoff_address: string;
          parcel_type: string;
          vehicle_type: VehicleType;
          delivery_speed: DeliverySpeed;
        };
        Update: Partial<Database["public"]["Tables"]["deliveries"]["Row"]>;
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          body: string;
          type: string;
          channel: string;
          read_at: string | null;
          metadata: Json;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["notifications"]["Row"]> & {
          user_id: string;
          title: string;
          body: string;
          type: string;
          channel: string;
        };
        Update: Partial<Database["public"]["Tables"]["notifications"]["Row"]>;
      };
      rider_documents: {
        Row: {
          id: string;
          rider_profile_id: string;
          document_type: string;
          file_url: string | null;
          storage_path: string | null;
          status: "submitted" | "approved" | "rejected" | "more_info_required";
          rejection_reason: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["rider_documents"]["Row"]> & {
          rider_profile_id: string;
          document_type: string;
        };
        Update: Partial<Database["public"]["Tables"]["rider_documents"]["Row"]>;
      };
      push_subscriptions: {
        Row: {
          id: string;
          user_id: string;
          endpoint: string;
          keys: Json;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["push_subscriptions"]["Row"]> & {
          user_id: string;
          endpoint: string;
        };
        Update: Partial<Database["public"]["Tables"]["push_subscriptions"]["Row"]>;
      };
      wallets: {
        Row: {
          id: string;
          user_id: string;
          wallet_type: WalletType;
          balance_ngn: number;
          locked_balance_ngn: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["wallets"]["Row"]> & {
          user_id: string;
          wallet_type: WalletType;
        };
        Update: Partial<Database["public"]["Tables"]["wallets"]["Row"]>;
      };
      transactions: {
        Row: {
          id: string;
          wallet_id: string;
          delivery_id: string | null;
          transaction_type: string;
          amount_ngn: number;
          status: string;
          provider: string | null;
          provider_reference: string | null;
          metadata: Json;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["transactions"]["Row"]> & {
          wallet_id: string;
          transaction_type: string;
          amount_ngn: number;
        };
        Update: Partial<Database["public"]["Tables"]["transactions"]["Row"]>;
      };
      withdrawal_requests: {
        Row: {
          id: string;
          rider_profile_id: string;
          amount_ngn: number;
          bank_name: string;
          account_number: string;
          account_name: string | null;
          status: "pending" | "approved" | "rejected" | "paid";
          rejection_reason: string | null;
          reviewed_by: string | null;
          reviewed_at: string | null;
          paid_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["withdrawal_requests"]["Row"]> & {
          rider_profile_id: string;
          amount_ngn: number;
          bank_name: string;
          account_number: string;
        };
        Update: Partial<Database["public"]["Tables"]["withdrawal_requests"]["Row"]>;
      };
      platform_launch_states: {
        Row: {
          id: string;
          state: string;
          status: "live" | "waitlist";
          launched_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["platform_launch_states"]["Row"]> & {
          state: string;
        };
        Update: Partial<Database["public"]["Tables"]["platform_launch_states"]["Row"]>;
      };
      state_waitlist: {
        Row: {
          id: string;
          user_id: string | null;
          email: string;
          phone: string | null;
          state: string;
          source: string;
          status: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["state_waitlist"]["Row"]> & {
          email: string;
          state: string;
        };
        Update: Partial<Database["public"]["Tables"]["state_waitlist"]["Row"]>;
      };
      rider_locations: {
        Row: {
          rider_profile_id: string;
          zone: string | null;
          latitude: number;
          longitude: number;
          heading: number | null;
          speed: number | null;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["rider_locations"]["Row"]> & {
          rider_profile_id: string;
          latitude: number;
          longitude: number;
        };
        Update: Partial<Database["public"]["Tables"]["rider_locations"]["Row"]>;
      };
    };
    Views: Record<string, never>;
    Functions: {
      create_wallet_funding: {
        Args: {
          next_user_id: string;
          next_wallet_type: WalletType;
          next_amount_ngn: number;
          next_provider: string;
          next_provider_reference: string;
          next_metadata?: Json;
        };
        Returns: string;
      };
      complete_wallet_funding: {
        Args: {
          next_provider_reference: string;
          next_amount_ngn: number;
          next_metadata?: Json;
        };
        Returns: string;
      };
      create_withdrawal_request: {
        Args: {
          target_rider_profile_id: string;
          next_amount_ngn: number;
        };
        Returns: string;
      };
      review_withdrawal_request: {
        Args: {
          request_id: string;
          next_status: string;
          rejection_note?: string | null;
        };
        Returns: string;
      };
    };
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
}
