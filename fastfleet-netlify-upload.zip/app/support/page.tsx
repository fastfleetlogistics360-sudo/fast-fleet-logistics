import type { Metadata } from "next";
import { Headphones, Mail, MessageCircle, Phone, TicketCheck } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { LinkButton } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";

export const metadata: Metadata = {
  title: "Support"
};

const cards: Array<[string, string, LucideIcon]> = [
  ["Order support", "Pickup edits, route issues, rider arrival, cancellation and delivery proof.", TicketCheck],
  ["Rider support", "Application status, document requests, wallet, delivery workflow.", Headphones],
  ["Business dispatch", "Vendor operations, saved addresses, bulk jobs, scheduled routes.", MessageCircle]
];

export default function SupportPage() {
  return (
    <section className="section-wrap py-8 sm:py-12">
      <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr] lg:items-start">
        <div>
          <span className="text-xs font-black uppercase tracking-[0.18em] text-fleet-ember">Support center</span>
          <h1 className="mt-3 text-4xl font-black leading-tight text-fleet-night sm:text-6xl">Dispatch help that keeps moving.</h1>
          <p className="mt-4 text-sm font-semibold leading-7 text-slate-600">
            Ticket infrastructure for customers, riders, vendors, business dispatchers, and operations teams.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <LinkButton href="/track">Track order</LinkButton>
            <LinkButton href="/book" variant="secondary">
              New delivery
            </LinkButton>
          </div>
        </div>
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <StatusBadge tone="green">Online</StatusBadge>
              <h2 className="mt-3 text-2xl font-black text-fleet-night">Create support ticket</h2>
            </div>
            <Headphones className="h-6 w-6 text-fleet-ember" />
          </div>
          <form className="mt-5 grid gap-4 sm:grid-cols-2">
            <label className="form-field">
              <span className="form-label">Name</span>
              <input className="form-input" placeholder="Your name" />
            </label>
            <label className="form-field">
              <span className="form-label">Phone</span>
              <input className="form-input" placeholder="+234..." />
            </label>
            <label className="form-field">
              <span className="form-label">Topic</span>
              <select className="form-input">
                <option>Delivery order</option>
                <option>Rider application</option>
                <option>Wallet and payments</option>
                <option>Business dispatch</option>
              </select>
            </label>
            <label className="form-field">
              <span className="form-label">Tracking code optional</span>
              <input className="form-input" placeholder="FF-..." />
            </label>
            <label className="form-field sm:col-span-2">
              <span className="form-label">Message</span>
              <textarea className="form-textarea" placeholder="How can FastFleet help?" />
            </label>
            <button className="rounded-fleet bg-fleet-ember px-5 py-3 text-sm font-black text-white shadow-lift sm:col-span-2" type="button">
              Send request
            </button>
          </form>
        </Card>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {cards.map(([title, body, Icon]) => (
          <Card key={title} className="p-5">
            <Icon className="h-5 w-5 text-fleet-ember" />
            <h3 className="mt-4 text-lg font-black text-fleet-night">{title}</h3>
            <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{body}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <Mail className="h-5 w-5 text-fleet-ember" />
          <h3 className="mt-4 text-lg font-black text-fleet-night">Email and notification structure</h3>
          <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
            Notification records support in-app, push, and email channels for order accepted, rider arrived, delivery completed, withdrawals, rider approvals, and promotions.
          </p>
        </Card>
        <Card className="p-5">
          <Phone className="h-5 w-5 text-fleet-ember" />
          <h3 className="mt-4 text-lg font-black text-fleet-night">Operations escalation</h3>
          <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
            Support tickets can be tied to deliveries, users, rider profiles, and admin SLA queues in Supabase.
          </p>
        </Card>
      </div>
    </section>
  );
}
