import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SiteShell } from "@/components/layout/site-shell";
import { PageTransition } from "@/components/motion/page-transition";
import { PwaRegister } from "@/components/layout/pwa-register";

export const metadata: Metadata = {
  title: {
    default: "FastFleet Logistics",
    template: "%s | FastFleet Logistics"
  },
  description: "Premium logistics marketplace for Lagos and Ogun deliveries, riders, fleets, wallets, and live tracking.",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: "/fastfleet-logo.png",
    apple: "/fastfleet-logo.png"
  },
  appleWebApp: {
    capable: true,
    title: "FastFleet",
    statusBarStyle: "black-translucent"
  }
};

export const viewport: Viewport = {
  themeColor: "#0f3460",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <PwaRegister />
        <SiteShell>
          <PageTransition>{children}</PageTransition>
        </SiteShell>
      </body>
    </html>
  );
}
