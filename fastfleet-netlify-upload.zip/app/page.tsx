import type { Metadata } from "next";
import { Activity, Navigation2 } from "lucide-react";
import { AdvertHeroSlider } from "@/components/landing/advert-hero-slider";
import { HowItWorks } from "@/components/landing/how-it-works";
import { RoutePreview } from "@/components/maps/route-preview";
import { Reveal } from "@/components/motion/reveal";
import { LinkButton } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";

export const metadata: Metadata = {
  title: "Premium Logistics Marketplace"
};

export default function LandingPage() {
  return (
    <>
      <AdvertHeroSlider />

      <section className="section-wrap py-12 sm:py-16">
        <div className="grid gap-6 lg:grid-cols-[0.92fr_1.08fr] lg:items-center">
          <Reveal>
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-2 text-xs font-black uppercase tracking-[0.16em] text-fleet-ember shadow-[0_12px_28px_rgba(8,17,31,0.08)]">
                <Activity className="h-4 w-4" />
                Live dispatch map
              </span>
              <h2 className="mt-4 text-3xl font-black leading-tight text-fleet-night sm:text-5xl">
                Your citywide delivery command view.
              </h2>
              <p className="mt-4 max-w-xl text-sm font-semibold leading-7 text-slate-600 sm:text-base">
                A clean realtime map layer for active riders, pickup routes, delivery zones, ETAs, and support visibility across Lagos and Ogun State.
              </p>
              <div className="mt-6 grid gap-3 sm:grid-cols-3">
                {[
                  ["91", "online riders"],
                  ["284", "active jobs"],
                  ["98%", "success rate"]
                ].map(([value, label]) => (
                  <Card key={label} className="p-4">
                    <strong className="block text-2xl font-black text-fleet-night">{value}</strong>
                    <span className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">{label}</span>
                  </Card>
                ))}
              </div>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <LinkButton href="/track">Track package</LinkButton>
                <LinkButton href="/dashboard" variant="secondary">
                  Open dashboard
                </LinkButton>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.12}>
            <Card className="relative overflow-hidden p-3">
              <RoutePreview className="min-h-[460px]" label="Realtime Lagos route" />
              <div className="absolute left-6 top-6 rounded-fleet border border-white/70 bg-white/92 p-3 shadow-lift backdrop-blur-xl">
                <StatusBadge tone="green">Rider online</StatusBadge>
                <strong className="mt-2 block text-sm font-black text-fleet-night">Lekki to Ikeja / 22 min</strong>
              </div>
              <div className="absolute bottom-6 right-6 hidden rounded-fleet border border-white/70 bg-white/92 p-3 shadow-lift backdrop-blur-xl sm:block">
                <div className="flex items-center gap-2 text-sm font-black text-fleet-night">
                  <Navigation2 className="h-4 w-4 text-fleet-ember" />
                  ETA recalculating
                </div>
              </div>
            </Card>
          </Reveal>
        </div>
      </section>

      <HowItWorks />
    </>
  );
}
