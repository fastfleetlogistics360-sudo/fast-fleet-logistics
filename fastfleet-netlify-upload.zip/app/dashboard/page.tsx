import type { Metadata } from "next";
import { CustomerDashboard } from "@/components/dashboard/customer-dashboard";

export const metadata: Metadata = {
  title: "Customer Dashboard"
};

export default function DashboardPage() {
  return <CustomerDashboard />;
}
