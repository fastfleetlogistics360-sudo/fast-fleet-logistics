import { Suspense } from "react";
import type { Metadata } from "next";
import { PhoneAuthForm } from "@/components/auth/phone-auth-form";
import { RoutePreview } from "@/components/maps/route-preview";

export const metadata: Metadata = {
  title: "Auth"
};

export default function AuthPage() {
  return (
    <section className="section-wrap grid gap-8 py-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-center lg:py-16">
      <div>
        <span className="text-xs font-black uppercase tracking-[0.18em] text-fleet-ember">Role-based access</span>
        <h2 className="mt-3 text-4xl font-black leading-tight text-fleet-night sm:text-6xl">Customer, rider, and admin sessions that stay secure.</h2>
        <p className="mt-4 max-w-2xl text-sm font-semibold leading-7 text-slate-600 sm:text-base">
          FastFleet uses Supabase phone OTP, persisted sessions, middleware route guards, and role metadata so each user lands in the right operational workspace.
        </p>
        <div className="mt-6">
          <RoutePreview compact label="Auth location context" />
        </div>
      </div>
      <Suspense>
        <PhoneAuthForm />
      </Suspense>
    </section>
  );
}
