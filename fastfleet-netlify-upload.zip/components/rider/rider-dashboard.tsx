"use client";

import { useEffect, useMemo, useState } from "react";
import { AlertCircle, ArrowDownToLine, Bell, Bike, CheckCircle2, Flag, Gauge, Loader2, PlayCircle, Star, ToggleLeft, ToggleRight, Wallet } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { formatMoney } from "@/lib/format";
import { isLaunchState, launchStateLabel, localLiveStates, normalizeState } from "@/lib/launch-states";
import { sampleRiders } from "@/lib/dispatch";
import { Card } from "@/components/ui/card";
import { LinkButton, Button } from "@/components/ui/button";
import { StatTile } from "@/components/ui/stat-tile";
import { StatusBadge } from "@/components/ui/status-badge";
import { RoutePreview } from "@/components/maps/route-preview";
import { WalletCard } from "@/components/wallet/wallet-card";
import { JoinStateWaitlistButton } from "@/components/waitlist/join-state-waitlist-button";

const jobs = [
  {
    code: "FF-REQ-901",
    pickup: "Lekki Phase 1",
    dropoff: "Victoria Island",
    vehicle: "Bike",
    timer: 24,
    earnings: 3850,
    distance: "5.8 km"
  },
  {
    code: "FF-REQ-902",
    pickup: "Ikoyi",
    dropoff: "Yaba",
    vehicle: "Bike",
    timer: 41,
    earnings: 5200,
    distance: "9.2 km"
  }
];

const transactions = [
  ["Delivery earning", "FF-240911", 3850],
  ["Withdrawal pending", "Kuda Bank", -12000],
  ["Bonus", "Gold streak", 2500]
];

const highlights: Array<[string, string, LucideIcon]> = [
  ["Completed deliveries", "182", CheckCircle2],
  ["Rider level", "Gold", Star],
  ["Performance", "Excellent", Gauge],
  ["Notifications", "8 unread", Bell]
];

type WalletTransaction = {
  id?: string;
  transaction_type: string;
  amount_ngn: number;
  status: string;
  provider?: string | null;
  created_at?: string;
};

type WithdrawalRequest = {
  id: string;
  amount_ngn: number;
  bank_name: string;
  account_number: string;
  account_name: string | null;
  status: "pending" | "approved" | "rejected" | "paid";
  rejection_reason: string | null;
  created_at: string;
  reviewed_at?: string | null;
};

export function RiderDashboard() {
  const [online, setOnline] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [tripStatus, setTripStatus] = useState("accepted");
  const [profile, setProfile] = useState<{ email?: string | null; phone?: string | null; default_zone?: string | null }>({ default_zone: "Lagos" });
  const [riderProfile, setRiderProfile] = useState<{
    id: string | null;
    application_status: string;
    bank_name?: string | null;
    account_number?: string | null;
    account_name?: string | null;
  }>({ id: null, application_status: "submitted" });
  const [walletBalance, setWalletBalance] = useState(145800);
  const [lockedBalance, setLockedBalance] = useState(0);
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>([]);
  const [withdrawalAmount, setWithdrawalAmount] = useState("3000");
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const [withdrawalLoading, setWithdrawalLoading] = useState(false);
  const [withdrawalMessage, setWithdrawalMessage] = useState<string | null>(null);
  const [liveStates, setLiveStates] = useState<string[]>(localLiveStates());
  const currentRider = sampleRiders()[0];
  const selectedState = normalizeState(profile.default_zone) || "Lagos";
  const kycApproved = riderProfile.application_status === "approved";
  const withdrawnLast24Hours = withdrawalRequests
    .filter((request) => new Date(request.created_at).getTime() >= Date.now() - 24 * 60 * 60 * 1000)
    .filter((request) => request.status !== "rejected")
    .reduce((sum, request) => sum + Number(request.amount_ngn || 0), 0);
  const metrics = useMemo(
    () => [
      ["Today earnings", formatMoney(28600), "6 completed deliveries"],
      ["Wallet balance", formatMoney(walletBalance), "Available for withdrawal"],
      ["Rating", currentRider.rating.toFixed(2), "Gold level rider"],
      ["Acceptance", `${currentRider.acceptanceRate}%`, "High dispatch priority"]
    ],
    [currentRider.acceptanceRate, currentRider.rating, walletBalance]
  );

  useEffect(() => {
    let cleanup: (() => void) | undefined;
    try {
      const supabase = createClient();
      supabase.auth.getUser().then(async ({ data }) => {
        if (!data.user) return;
        await supabase.from("rider_profiles").update({ online }).eq("user_id", data.user.id);
        const riderResult = await supabase
          .from("rider_profiles")
          .select("id, application_status, bank_name, account_number, account_name")
          .eq("user_id", data.user.id)
          .maybeSingle();
        setRiderProfile({
          id: riderResult.data?.id || null,
          application_status: riderResult.data?.application_status || "submitted",
          bank_name: riderResult.data?.bank_name,
          account_number: riderResult.data?.account_number,
          account_name: riderResult.data?.account_name
        });
        const profileResult = await supabase.from("users").select("email, phone, default_zone").eq("id", data.user.id).maybeSingle();
        setProfile(profileResult.data || { email: data.user.email, phone: data.user.phone, default_zone: "Lagos" });
        const launchResult = await supabase.from("platform_launch_states").select("state, status").eq("status", "live");
        if (launchResult.data?.length) setLiveStates(Array.from(new Set([...localLiveStates(), ...launchResult.data.map((row) => row.state)])));
        const walletResult = await supabase
          .from("wallets")
          .select("id, balance_ngn, locked_balance_ngn")
          .eq("user_id", data.user.id)
          .eq("wallet_type", "rider")
          .maybeSingle();
        if (walletResult.data) {
          setWalletBalance(Number(walletResult.data.balance_ngn || 0));
          setLockedBalance(Number(walletResult.data.locked_balance_ngn || 0));
          const transactionResult = await supabase
            .from("transactions")
            .select("id, transaction_type, amount_ngn, status, provider, created_at")
            .eq("wallet_id", walletResult.data.id)
            .order("created_at", { ascending: false })
            .limit(6);
          setWalletTransactions(transactionResult.data || []);
        }
        if (riderResult.data?.id) {
          const withdrawalResult = await supabase
            .from("withdrawal_requests")
            .select("id, amount_ngn, bank_name, account_number, account_name, status, rejection_reason, created_at, reviewed_at")
            .eq("rider_profile_id", riderResult.data.id)
            .order("created_at", { ascending: false })
            .limit(8);
          setWithdrawalRequests((withdrawalResult.data || []) as WithdrawalRequest[]);
        }
      });

      const channel = supabase
        .channel("rider-delivery-requests")
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "deliveries" }, () => {
          setToast("New delivery request received.");
        })
        .subscribe();
      cleanup = () => {
        supabase.removeChannel(channel);
      };
    } catch {
      cleanup = undefined;
    }
    return () => cleanup?.();
  }, [online]);

  useEffect(() => {
    if (!online || !riderProfile.id || tripStatus === "delivered" || typeof navigator === "undefined" || !navigator.geolocation) return;

    const watchId = navigator.geolocation.watchPosition(
      async (position) => {
        try {
          const supabase = createClient();
          await supabase.from("rider_locations").upsert({
            rider_profile_id: riderProfile.id,
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            heading: position.coords.heading,
            speed: position.coords.speed,
            zone: profile.default_zone || "Lagos",
            updated_at: new Date().toISOString()
          });
        } catch {
          // Location sharing is optional in demo mode and depends on browser permission.
        }
      },
      () => undefined,
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 15000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [online, profile.default_zone, riderProfile.id, tripStatus]);

  async function requestWithdrawal() {
    const amount = Number(withdrawalAmount);
    setWithdrawalMessage(null);
    if (!riderProfile.id) {
      setWithdrawalMessage("Complete driver onboarding before requesting a withdrawal.");
      return;
    }
    if (!kycApproved) {
      setWithdrawalMessage("Your KYC must be approved before withdrawals are enabled.");
      return;
    }
    if (amount < 3000 || amount > 200000) {
      setWithdrawalMessage("Withdrawal amount must be between NGN 3,000 and NGN 200,000.");
      return;
    }
    if (withdrawnLast24Hours + amount > 200000) {
      setWithdrawalMessage("Your 24-hour withdrawal limit is NGN 200,000. The limit resets after 24 hours.");
      return;
    }
    if (amount > walletBalance) {
      setWithdrawalMessage("Your available balance is not enough for this withdrawal.");
      return;
    }

    setWithdrawalLoading(true);
    try {
      const supabase = createClient();
      const { data, error } = await supabase.rpc("create_withdrawal_request", {
        target_rider_profile_id: riderProfile.id,
        next_amount_ngn: amount
      });
      if (error) throw error;
      const request: WithdrawalRequest = {
        id: String(data || `local-${Date.now()}`),
        amount_ngn: amount,
        bank_name: riderProfile.bank_name || "Bank pending",
        account_number: riderProfile.account_number || "Account pending",
        account_name: riderProfile.account_name || null,
        status: "pending",
        rejection_reason: null,
        created_at: new Date().toISOString()
      };
      setWithdrawalRequests((current) => [request, ...current]);
      setLockedBalance((value) => value + amount);
      setWalletBalance((value) => value - amount);
      setWithdrawalMessage("Withdrawal request sent. Admin will approve or reject it before payout within 24 hours.");
    } catch (error) {
      setWithdrawalMessage(error instanceof Error ? error.message : "Could not request withdrawal.");
    } finally {
      setWithdrawalLoading(false);
    }
  }

  async function updateTrip(status: "picked_up" | "delivered") {
    setTripStatus(status);
    setToast(status === "picked_up" ? "Trip started. Customer can now watch the delivery move live." : "Trip ended. Delivery marked as completed.");
    try {
      const supabase = createClient();
      const updatePayload =
        status === "picked_up"
          ? { status, picked_up_at: new Date().toISOString() }
          : { status, delivered_at: new Date().toISOString() };
      await supabase
        .from("deliveries")
        .update(updatePayload)
        .eq("delivery_code", "FF-240911");
    } catch {
      // Demo mode keeps the local trip controls responsive without Supabase env vars.
    }
  }

  if (!isLaunchState(selectedState, liveStates)) {
    return <RiderComingSoon state={selectedState} profile={profile} liveStates={liveStates} />;
  }

  return (
    <section className="section-wrap py-8 sm:py-12">
      <div className="grid gap-6 lg:grid-cols-[0.78fr_1.22fr]">
        <Card className="p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.18em] text-fleet-ember">Rider dashboard</span>
              <h1 className="mt-3 text-4xl font-black leading-tight text-fleet-night sm:text-5xl">Welcome, Tunde.</h1>
              <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">
                Manage job requests, earnings, route previews, ratings, withdrawals, and support from one dispatch cockpit.
              </p>
            </div>
            <StatusBadge tone={online ? "green" : "neutral"}>{online ? "Online" : "Offline"}</StatusBadge>
          </div>
          <button
            type="button"
            onClick={() => setOnline((value) => !value)}
            className={`mt-6 flex w-full items-center justify-between rounded-fleet border p-4 text-left transition ${
              online ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-fleet-line bg-fleet-paper text-slate-600"
            }`}
          >
            <span>
              <strong className="block text-sm font-black">Availability</strong>
              <span className="text-xs font-bold">{online ? "Receiving delivery requests" : "Paused from dispatch queue"}</span>
            </span>
            {online ? <ToggleRight className="h-7 w-7" /> : <ToggleLeft className="h-7 w-7" />}
          </button>
          {toast ? <div className="mt-4 rounded-fleet bg-fleet-night p-3 text-sm font-bold text-white">{toast}</div> : null}
        </Card>

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {metrics.map(([label, value, helper]) => (
            <StatTile key={label} label={label} value={value} helper={helper} />
          ))}
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Available jobs</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">Delivery requests</h2>
            </div>
            <StatusBadge tone="amber">Accept timer</StatusBadge>
          </div>
          <div className="mt-5 grid gap-3">
            {jobs.map((job) => (
              <article key={job.code} className="rounded-fleet border border-fleet-line bg-white p-4 shadow-[0_10px_22px_rgba(8,17,31,0.05)]">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <strong className="block font-black text-fleet-night">{job.code}</strong>
                    <span className="text-xs font-bold text-slate-500">
                      {job.pickup} to {job.dropoff}
                    </span>
                  </div>
                  <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-black text-amber-700">{job.timer}s</span>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-xs font-black text-slate-600">
                  <span className="rounded-fleet bg-fleet-paper px-2 py-2">{job.vehicle}</span>
                  <span className="rounded-fleet bg-fleet-paper px-2 py-2">{job.distance}</span>
                  <span className="rounded-fleet bg-fleet-paper px-2 py-2">{formatMoney(job.earnings)}</span>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <Button type="button" variant="secondary">Reject</Button>
                  <Button type="button">Accept</Button>
                </div>
              </article>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Route preview</span>
          <h2 className="mt-1 text-2xl font-black text-fleet-night">Next pickup</h2>
          <div className="mt-4">
            <RoutePreview compact label="Rider route" status={tripStatus} riderName="Tunde Adebayo" />
          </div>
          <div className="mt-5 rounded-fleet border border-fleet-line bg-fleet-paper p-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Active trip</span>
                <strong className="mt-1 block text-lg font-black text-fleet-night">FF-240911</strong>
                <span className="text-xs font-bold text-slate-500">Package pickup to customer delivery</span>
              </div>
              <StatusBadge tone={tripStatus === "delivered" ? "green" : "amber"}>{tripStatus.replaceAll("_", " ")}</StatusBadge>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <Button type="button" variant="secondary" onClick={() => updateTrip("picked_up")} disabled={tripStatus === "delivered"}>
                <PlayCircle className="h-4 w-4" />
                Start trip
              </Button>
              <Button type="button" onClick={() => updateTrip("delivered")} disabled={tripStatus === "delivered"}>
                <Flag className="h-4 w-4" />
                End trip
              </Button>
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {highlights.map(([label, value, Icon]) => (
          <Card key={label} className="p-5">
            <Icon className="h-5 w-5 text-fleet-ember" />
            <strong className="mt-4 block text-2xl font-black text-fleet-night">{value}</strong>
            <span className="text-sm font-bold text-slate-500">{label}</span>
          </Card>
        ))}
      </div>

      <div className="mt-6">
        <WalletCard
          title="Rider wallet"
          walletType="rider"
          balance={walletBalance}
          lockedBalance={lockedBalance}
          transactions={walletTransactions}
          helper="Track earnings, bonuses, withdrawals, and optional wallet funding."
        />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Withdrawal controls</span>
              <strong className="mt-2 block text-4xl font-black text-fleet-night">{formatMoney(walletBalance)}</strong>
              <span className="mt-1 block text-xs font-bold text-slate-500">
                24-hour usage: {formatMoney(withdrawnLast24Hours)} / {formatMoney(200000)}
              </span>
            </div>
            <StatusBadge tone={kycApproved ? "green" : "amber"}>{kycApproved ? "KYC approved" : "KYC pending"}</StatusBadge>
          </div>
          <div className="mt-5 grid gap-3">
            <label className="form-field">
              <span className="form-label">Withdrawal amount</span>
              <input
                className="form-input"
                value={withdrawalAmount}
                onChange={(event) => setWithdrawalAmount(event.target.value)}
                inputMode="numeric"
                placeholder="3000"
              />
            </label>
            <div className="grid grid-cols-2 gap-3">
              <Button type="button" onClick={requestWithdrawal} disabled={withdrawalLoading || !kycApproved}>
                {withdrawalLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowDownToLine className="h-4 w-4" />}
                Withdraw earning
              </Button>
              <LinkButton href="/support" variant="secondary">
                <Wallet className="h-4 w-4" />
                Support
              </LinkButton>
            </div>
          </div>
          <div className="mt-4 rounded-fleet bg-fleet-paper p-3 text-xs font-bold leading-5 text-slate-600">
            Minimum withdrawal is NGN 3,000. Maximum is NGN 200,000 per 24 hours. Admin approval is required before payout.
          </div>
          {!kycApproved ? (
            <div className="mt-3 flex gap-2 rounded-fleet bg-amber-50 p-3 text-xs font-bold leading-5 text-amber-800">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              Upload and pass KYC verification before withdrawal requests can be approved.
            </div>
          ) : null}
          {withdrawalMessage ? <div className="mt-3 rounded-fleet bg-amber-50 p-3 text-xs font-bold leading-5 text-amber-800">{withdrawalMessage}</div> : null}
        </Card>

        <Card className="p-5">
          <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Withdrawal status</span>
          <div className="mt-4 grid gap-3">
            {withdrawalRequests.length === 0 ? (
              <div className="rounded-fleet bg-fleet-paper p-3 text-sm font-bold text-slate-500">No withdrawal requests yet.</div>
            ) : (
              withdrawalRequests.map((request) => (
                <div key={request.id} className="rounded-fleet border border-fleet-line bg-white p-3">
                  <div className="flex items-center justify-between gap-4">
                    <span>
                      <strong className="block text-sm font-black text-fleet-night">{formatMoney(Number(request.amount_ngn || 0))}</strong>
                      <span className="text-xs font-bold text-slate-500">
                        {request.bank_name} · {request.account_number}
                      </span>
                    </span>
                    <StatusBadge tone={request.status === "approved" || request.status === "paid" ? "green" : request.status === "rejected" ? "red" : "amber"}>
                      {request.status}
                    </StatusBadge>
                  </div>
                  {request.status === "approved" ? (
                    <p className="mt-2 text-xs font-bold leading-5 text-emerald-700">Approved. You will be credited before 24 hours.</p>
                  ) : null}
                  {request.rejection_reason ? (
                    <p className="mt-2 text-xs font-black leading-5 text-rose-700">{request.rejection_reason}</p>
                  ) : null}
                </div>
              ))
            )}
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Driver earnings</span>
              <strong className="mt-2 block text-2xl font-black text-fleet-night">Every dashboard includes withdrawals</strong>
            </div>
            <Wallet className="h-5 w-5 text-fleet-ember" />
          </div>
          <div className="mt-4 grid gap-3 text-sm font-bold text-slate-600">
            <div className="rounded-fleet bg-fleet-paper p-3">Available: {formatMoney(walletBalance)}</div>
            <div className="rounded-fleet bg-fleet-paper p-3">Locked for pending withdrawals: {formatMoney(lockedBalance)}</div>
            <div className="rounded-fleet bg-fleet-paper p-3">KYC status: {riderProfile.application_status.replaceAll("_", " ")}</div>
          </div>
        </Card>

        <Card className="p-5">
          <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Transaction history</span>
          <div className="mt-4 grid gap-3">
            {transactions.map(([label, detail, amount]) => (
              <div key={`${label}-${detail}`} className="flex items-center justify-between gap-4 rounded-fleet bg-fleet-paper p-3">
                <span>
                  <strong className="block text-sm font-black text-fleet-night">{label}</strong>
                  <span className="text-xs font-bold text-slate-500">{detail}</span>
                </span>
                <strong className={Number(amount) < 0 ? "text-rose-600" : "text-emerald-700"}>{formatMoney(Math.abs(Number(amount)))}</strong>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
}

function RiderComingSoon({
  state,
  profile,
  liveStates
}: {
  state: string;
  profile: { email?: string | null; phone?: string | null };
  liveStates: string[];
}) {
  return (
    <section className="section-wrap py-10 sm:py-14">
      <Card className="grid gap-0 overflow-hidden lg:grid-cols-[0.96fr_1.04fr]">
        <div className="p-6 sm:p-8">
          <span className="inline-flex items-center gap-2 rounded-full bg-amber-50 px-3 py-1 text-xs font-black uppercase tracking-[0.16em] text-amber-700">
            <Bell className="h-4 w-4" />
            Rider launch waitlist
          </span>
          <h1 className="mt-5 text-4xl font-black leading-tight text-fleet-night sm:text-6xl">COMING SOON TO YOUR STATE</h1>
          <p className="mt-4 max-w-xl text-sm font-semibold leading-7 text-slate-600 sm:text-base">
            Rider operations are live in {launchStateLabel(liveStates)}. Your {state} rider profile can stay on the waitlist while we prepare dispatch coverage there.
          </p>
          <div className="mt-7">
            <JoinStateWaitlistButton state={state} email={profile.email} phone={profile.phone} />
          </div>
        </div>
        <div className="min-h-[360px] bg-fleet-night p-4">
          <RoutePreview className="h-full min-h-[330px]" label={`${state} rider launch`} status="searching" riderName="Rider network preparing" />
        </div>
      </Card>
    </section>
  );
}
