"use client";

import { useState } from "react";
import { CreditCard, Loader2, ShieldCheck, Wallet } from "lucide-react";
import { formatMoney } from "@/lib/format";
import type { WalletType } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";

type WalletTransaction = {
  id?: string;
  transaction_type: string;
  amount_ngn: number;
  status: string;
  provider?: string | null;
  created_at?: string;
};

export function WalletCard({
  title = "Wallet",
  balance,
  lockedBalance = 0,
  walletType,
  transactions = [],
  helper
}: {
  title?: string;
  balance: number;
  lockedBalance?: number;
  walletType: WalletType;
  transactions?: WalletTransaction[];
  helper?: string;
}) {
  const [amount, setAmount] = useState("10000");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function topUp() {
    setLoading(true);
    setMessage(null);
    try {
      const response = await fetch("/api/wallet/topup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: Number(amount), walletType })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not start wallet funding.");
      window.location.assign(data.authorizationUrl);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not start wallet funding.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="overflow-hidden">
      <div className="border-b border-fleet-line bg-fleet-night p-5 text-white">
        <div className="flex items-start justify-between gap-4">
          <div>
            <span className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-fleet-gold">
              <Wallet className="h-4 w-4" />
              {title}
            </span>
            <strong className="mt-3 block text-4xl font-black">{formatMoney(balance)}</strong>
            <p className="mt-2 text-sm font-semibold text-white/70">{helper || "Fund, spend, refund, and reconcile from one balance."}</p>
          </div>
          <StatusBadge tone="green" className="bg-emerald-400/15 text-emerald-100">
            Paystack ready
          </StatusBadge>
        </div>
        {lockedBalance > 0 ? (
          <div className="mt-4 rounded-fleet border border-white/10 bg-white/10 p-3 text-sm font-bold text-white/80">
            {formatMoney(lockedBalance)} locked for active deliveries
          </div>
        ) : null}
      </div>

      <div className="grid gap-5 p-5 lg:grid-cols-[0.92fr_1.08fr]">
        <div className="grid gap-3">
          <label className="form-field">
            <span className="form-label">Top up amount</span>
            <input
              className="form-input"
              value={amount}
              onChange={(event) => setAmount(event.target.value.replace(/[^\d]/g, ""))}
              inputMode="numeric"
              placeholder="10000"
            />
          </label>
          <Button type="button" onClick={topUp} disabled={loading || Number(amount) < 500}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
            Top up with Paystack
          </Button>
          <div className="flex items-start gap-2 rounded-fleet bg-emerald-50 p-3 text-xs font-bold leading-5 text-emerald-800">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
            Payment is verified server-side before your wallet is credited.
          </div>
          {message ? <div className="rounded-fleet border border-amber-200 bg-amber-50 p-3 text-sm font-bold text-amber-800">{message}</div> : null}
        </div>

        <div>
          <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Recent wallet activity</span>
          <div className="mt-3 grid gap-2">
            {(transactions.length ? transactions : sampleTransactions).slice(0, 4).map((transaction, index) => (
              <div key={transaction.id || `${transaction.transaction_type}-${index}`} className="flex items-center justify-between gap-4 rounded-fleet bg-fleet-paper p-3">
                <span>
                  <strong className="block text-sm font-black capitalize text-fleet-night">{transaction.transaction_type.replaceAll("_", " ")}</strong>
                  <span className="text-xs font-bold text-slate-500">{transaction.provider || transaction.status}</span>
                </span>
                <strong className={transaction.amount_ngn < 0 ? "text-rose-600" : "text-emerald-700"}>
                  {transaction.amount_ngn < 0 ? "-" : "+"}
                  {formatMoney(Math.abs(transaction.amount_ngn))}
                </strong>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

const sampleTransactions: WalletTransaction[] = [
  { transaction_type: "wallet_funding", amount_ngn: 25000, status: "successful", provider: "Paystack" },
  { transaction_type: "delivery_payment", amount_ngn: -10850, status: "successful", provider: "FastFleet" },
  { transaction_type: "refund", amount_ngn: 1800, status: "successful", provider: "Support" }
];
