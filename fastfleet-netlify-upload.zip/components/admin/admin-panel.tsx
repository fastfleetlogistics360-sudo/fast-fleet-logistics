"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Bike,
  CheckCircle2,
  CircleDollarSign,
  ClipboardCheck,
  FilePenLine,
  Globe2,
  LockKeyhole,
  LogOut,
  Map,
  Megaphone,
  PauseCircle,
  Power,
  RefreshCw,
  ShieldAlert,
  SlidersHorizontal,
  TicketCheck,
  UsersRound,
  WalletCards
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { defaultLaunchStateRecords, rememberLiveState } from "@/lib/launch-states";
import type { LaunchStateRecord } from "@/lib/launch-states";
import { formatMoney } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatTile } from "@/components/ui/stat-tile";
import { StatusBadge } from "@/components/ui/status-badge";

const approvals: Array<[string, string, string, string]> = [
  ["Amina Yusuf", "Bike", "Lekki / VI", "under review"],
  ["Samuel Ojo", "Car", "Ikeja / Ogba", "more info required"],
  ["Kunle Balogun", "Van", "Ota / Ogun", "submitted"]
];

const heatmap: Array<[string, number]> = [
  ["Lekki", 96],
  ["VI", 82],
  ["Ikeja", 78],
  ["Yaba", 64],
  ["Ota", 53],
  ["Abeokuta", 47]
];

const metrics: Array<[string, string, string]> = [
  ["GMV", "NGN 42.8m", "+18% month"],
  ["Active riders", "184", "91 online now"],
  ["Success rate", "98.2%", "2.1% cancellations"],
  ["Open tickets", "23", "7 urgent"]
];

type AdminFeature = {
  title: string;
  body: string;
  icon: LucideIcon;
};

const controlFeatures: AdminFeature[] = [
  { title: "Customer management", body: "Profiles, wallet balances, order history, support context.", icon: UsersRound },
  { title: "Pricing controls", body: "Vehicle base fares, per-km fees, surge, commission rates.", icon: SlidersHorizontal },
  { title: "Fraud detection", body: "Velocity checks, payment mismatch, location anomalies.", icon: ShieldAlert },
  { title: "Rider controls", body: "Suspend, reinstate, zone lock, document re-check.", icon: PauseCircle }
];

const editableControls: AdminFeature[] = [
  { title: "Hero slider", body: "Swap campaign images, copy, CTAs, and active order.", icon: Megaphone },
  { title: "Social links", body: "Manage Instagram, Facebook, LinkedIn, and X URLs.", icon: CheckCircle2 },
  { title: "Wallet policy", body: "Review top-up limits, locked balances, refunds, and fees.", icon: WalletCards },
  { title: "Service switches", body: "Pause bookings, rider onboarding, or state launches.", icon: Power }
];

const financialMetrics: Array<{ label: string; value: string; helper: string }> = [
  { label: "Pending wallet credits", value: "12", helper: "Verify Paystack references before support escalation" },
  { label: "Refund queue", value: formatMoney(186400), helper: "Reverse or approve customer balance refunds" },
  { label: "Rider withdrawals", value: "27", helper: "Bank payout approvals and hold controls" },
  { label: "Platform commission", value: formatMoney(782000), helper: "Daily commission capture estimate" }
];

type AdminWithdrawal = {
  id: string;
  amount_ngn: number;
  bank_name: string;
  account_number: string;
  account_name: string | null;
  status: "pending" | "approved" | "rejected" | "paid";
  rejection_reason: string | null;
  created_at: string;
  rider_profiles?: {
    application_status?: string | null;
    vehicle_type?: string | null;
    operating_zone?: string | null;
    users?: {
      full_name?: string | null;
      phone?: string | null;
      email?: string | null;
    } | null;
  } | null;
};

const demoWithdrawals: AdminWithdrawal[] = [
  {
    id: "WR-901",
    amount_ngn: 24000,
    bank_name: "Kuda Bank",
    account_number: "2034567890",
    account_name: "Tunde Adebayo",
    status: "pending",
    rejection_reason: null,
    created_at: new Date().toISOString(),
    rider_profiles: {
      application_status: "approved",
      vehicle_type: "bike",
      operating_zone: "Lagos",
      users: { full_name: "Tunde Adebayo", phone: "+2348012345678", email: "tunde@example.com" }
    }
  }
];

export function AdminPanel() {
  const [liveCount, setLiveCount] = useState(284);
  const [launchStates, setLaunchStates] = useState<LaunchStateRecord[]>(defaultLaunchStateRecords());
  const [adminWithdrawals, setAdminWithdrawals] = useState<AdminWithdrawal[]>(demoWithdrawals);
  const [adminMessage, setAdminMessage] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [pricing, setPricing] = useState({ surge: "1.15", commission: "18", bikeBase: "1800" });
  const liveStates = useMemo(() => launchStates.filter((state) => state.status === "live").length, [launchStates]);
  const pendingWithdrawalCount = useMemo(() => adminWithdrawals.filter((withdrawal) => withdrawal.status === "pending").length, [adminWithdrawals]);

  useEffect(() => {
    loadAdminData();
  }, []);

  async function loadAdminData() {
    setBusyAction("refresh");
    try {
      const [statesResponse, withdrawalsResponse] = await Promise.all([fetch("/api/admin/states"), fetch("/api/admin/withdrawals")]);
      const statesResult = await statesResponse.json().catch(() => ({}));
      const withdrawalsResult = await withdrawalsResponse.json().catch(() => ({}));

      if (Array.isArray(statesResult.states)) setLaunchStates(statesResult.states);
      if (Array.isArray(withdrawalsResult.withdrawals) && withdrawalsResult.withdrawals.length > 0) {
        setAdminWithdrawals(withdrawalsResult.withdrawals);
      }
      if (statesResult.demo || withdrawalsResult.demo) {
        setAdminMessage("Admin is running in demo mode. Add SUPABASE_SERVICE_ROLE_KEY in Netlify to make go-live and withdrawal approvals write to Supabase.");
      }
    } catch {
      setAdminMessage("Could not reach the admin API. Showing saved demo data for now.");
    } finally {
      setBusyAction(null);
    }
  }

  async function goLive(state: string) {
    setBusyAction(`state:${state}`);
    setAdminMessage(null);
    try {
      const response = await fetch("/api/admin/states", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ state })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Could not launch this state.");
      rememberLiveState(state);
      setLaunchStates((current) =>
        current.map((item) => (item.state === state ? { ...item, status: "live", launched_at: result.launched_at || new Date().toISOString() } : item))
      );
      setAdminMessage(`${state} is now live. Users in that state will see the full dashboard automatically.`);
    } catch (error) {
      setAdminMessage(error instanceof Error ? error.message : "Could not launch this state.");
    } finally {
      setBusyAction(null);
    }
  }

  async function reviewWithdrawal(id: string, status: "approved" | "rejected" | "paid") {
    const current = adminWithdrawals.find((withdrawal) => withdrawal.id === id);
    const reason =
      status === "rejected"
        ? window.prompt("Reason to show the driver in red on their withdrawal status:")?.trim()
        : "";
    if (status === "rejected" && !reason) return;

    setBusyAction(`withdrawal:${id}:${status}`);
    setAdminMessage(null);
    try {
      const response = await fetch("/api/admin/withdrawals", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status, reason })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Could not review withdrawal.");
      setAdminWithdrawals((items) =>
        items.map((item) => (item.id === id ? { ...item, status, rejection_reason: status === "rejected" ? reason || null : item.rejection_reason } : item))
      );
      setAdminMessage(
        status === "approved"
          ? `${current?.account_name || "Driver"} withdrawal approved. Payout should be credited within 24 hours.`
          : status === "paid"
            ? `${current?.account_name || "Driver"} withdrawal marked as paid.`
            : `${current?.account_name || "Driver"} withdrawal rejected with a visible driver reason.`
      );
    } catch (error) {
      setAdminMessage(error instanceof Error ? error.message : "Could not review withdrawal.");
    } finally {
      setBusyAction(null);
    }
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    window.location.reload();
  }

  useEffect(() => {
    const timer = window.setInterval(() => {
      setLiveCount((value) => value + 1);
    }, 30000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <section className="section-wrap py-8 sm:py-12">
      <div className="grid gap-6 lg:grid-cols-[0.78fr_1.22fr]">
        <div>
          <span className="text-xs font-black uppercase tracking-[0.18em] text-fleet-ember">Admin panel</span>
          <h1 className="mt-3 text-4xl font-black leading-tight text-fleet-night sm:text-6xl">Operate FastFleet with confidence.</h1>
          <p className="mt-4 text-sm font-semibold leading-7 text-slate-600">
            Monitor riders, deliveries, payouts, pricing, support, fraud signals, zones, and growth metrics from one premium command center.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Button type="button" variant="secondary" onClick={loadAdminData} disabled={busyAction === "refresh"}>
              <RefreshCw className={`h-4 w-4 ${busyAction === "refresh" ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <Button type="button" variant="dark" onClick={logout}>
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <StatTile label="Live states" value={String(liveStates)} helper="Open dashboard access" />
          <StatTile label="Pending withdrawals" value={String(pendingWithdrawalCount)} helper="Need admin review" />
          {metrics.map(([label, value, helper]) => (
            <StatTile key={label} label={label} value={value} helper={helper} />
          ))}
        </div>
      </div>

      {adminMessage ? <div className="mt-5 rounded-fleet bg-amber-50 p-4 text-sm font-bold leading-6 text-amber-800">{adminMessage}</div> : null}

      <div className="mt-6 grid gap-4 xl:grid-cols-3">
        <Card className="p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Launch authority</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">State availability</h2>
            </div>
            <Globe2 className="h-5 w-5 text-fleet-ember" />
          </div>
          <div className="mt-5 grid max-h-[420px] gap-3 overflow-auto pr-1">
            {launchStates.map(({ state, status, waitlist_count }) => (
              <div key={state} className="flex items-center justify-between gap-4 rounded-fleet border border-fleet-line bg-white p-3 text-left">
                <span>
                  <strong className="block text-sm font-black text-fleet-night">{state}</strong>
                  <span className="text-xs font-bold text-slate-500">{waitlist_count || 0} waiting</span>
                </span>
                {status === "live" ? (
                  <StatusBadge tone="green">Open</StatusBadge>
                ) : (
                  <Button type="button" size="sm" onClick={() => goLive(state)} disabled={busyAction === `state:${state}`}>
                    <Power className="h-4 w-4" />
                    Go live
                  </Button>
                )}
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Pricing authority</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">Fare controls</h2>
            </div>
            <SlidersHorizontal className="h-5 w-5 text-fleet-ember" />
          </div>
          <div className="mt-5 grid gap-3">
            <AdminInput label="Bike base fare" value={pricing.bikeBase} onChange={(value) => setPricing((current) => ({ ...current, bikeBase: value }))} />
            <AdminInput label="Surge multiplier" value={pricing.surge} onChange={(value) => setPricing((current) => ({ ...current, surge: value }))} />
            <AdminInput label="Commission percent" value={pricing.commission} onChange={(value) => setPricing((current) => ({ ...current, commission: value }))} />
          </div>
          <Button type="button" className="mt-4 w-full">
            Save pricing draft
          </Button>
        </Card>

        <Card className="p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Admin access</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">Login and URL</h2>
            </div>
            <LockKeyhole className="h-5 w-5 text-fleet-ember" />
          </div>
          <div className="mt-5 grid gap-3 text-sm font-bold text-slate-600">
            <div className="rounded-fleet bg-fleet-paper p-3">
              Admin route: <span className="text-fleet-night">/admin</span>
            </div>
            <div className="rounded-fleet bg-fleet-paper p-3">
              Username: <span className="text-fleet-night">FastFleetAdmin</span>
            </div>
            <div className="rounded-fleet bg-emerald-50 p-3 text-emerald-800">
              Admin login is separate from customer and driver registration.
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Live deliveries</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">{liveCount} active routes</h2>
            </div>
            <StatusBadge tone="green">Realtime</StatusBadge>
          </div>
          <div className="mt-6 grid h-72 items-end gap-3 rounded-fleet border border-fleet-line bg-fleet-paper p-4 sm:grid-cols-7">
            {[42, 58, 64, 91, 78, 104, 86].map((value, index) => (
              <div key={index} className="flex h-full flex-col justify-end gap-2">
                <div
                  className="rounded-t-fleet bg-gradient-to-t from-fleet-ember to-fleet-leaf"
                  style={{ height: `${Math.min(100, value)}%` }}
                />
                <span className="text-center text-xs font-black text-slate-500">D{index + 1}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Zone heatmap</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">Demand by area</h2>
            </div>
            <Map className="h-5 w-5 text-fleet-ember" />
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3">
            {heatmap.map(([zone, value]) => (
              <div key={zone} className="rounded-fleet border border-fleet-line bg-white p-3">
                <div className="flex items-center justify-between">
                  <strong className="text-sm font-black text-fleet-night">{zone}</strong>
                  <span className="text-xs font-black text-fleet-ember">{value}%</span>
                </div>
                <div className="mt-3 h-2 rounded-full bg-fleet-paper">
                  <div className="h-2 rounded-full bg-fleet-ember" style={{ width: `${value}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[0.85fr_1.15fr]">
        <AdminTable
          icon={ClipboardCheck}
          title="Rider approvals"
          subtitle="Manual review queue"
          rows={approvals.map(([name, vehicle, zone, status]) => [name, vehicle, zone, status])}
          actions={["Approve", "More info", "Reject"]}
        />
        <DriverWithdrawalSection
          withdrawals={adminWithdrawals}
          busyAction={busyAction}
          onReview={reviewWithdrawal}
        />
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {controlFeatures.map(({ title, body, icon: Icon }) => (
          <Card key={title} className="p-5">
            <Icon className="h-5 w-5 text-fleet-ember" />
            <h3 className="mt-4 text-lg font-black text-fleet-night">{title}</h3>
            <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{body}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <Card className="p-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Site authority</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">Editable platform controls</h2>
            </div>
            <FilePenLine className="h-5 w-5 text-fleet-ember" />
          </div>
          <div className="mt-5 grid gap-3">
            {editableControls.map(({ title, body, icon: Icon }) => (
              <div
                key={title}
                className="flex items-center justify-between gap-4 rounded-fleet border border-fleet-line bg-white p-4"
              >
                <span className="flex items-start gap-3">
                  <Icon className="mt-0.5 h-5 w-5 text-fleet-ember" />
                  <span>
                    <strong className="block text-sm font-black text-fleet-night">{title}</strong>
                    <span className="text-xs font-bold leading-5 text-slate-500">{body}</span>
                  </span>
                </span>
                <Button type="button" size="sm" variant="secondary">
                  Edit
                </Button>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-black uppercase tracking-[0.16em] text-fleet-ember">Financial control</span>
              <h2 className="mt-1 text-2xl font-black text-fleet-night">Wallet and Paystack oversight</h2>
            </div>
            <WalletCards className="h-5 w-5 text-fleet-ember" />
          </div>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {financialMetrics.map(({ label, value, helper }) => (
              <div key={label} className="rounded-fleet border border-fleet-line bg-fleet-paper p-4">
                <span className="text-xs font-black uppercase tracking-[0.14em] text-slate-500">{label}</span>
                <strong className="mt-2 block text-2xl font-black text-fleet-night">{value}</strong>
                <p className="mt-1 text-xs font-bold leading-5 text-slate-500">{helper}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <OpsPanel icon={Bike} title="Active rider monitoring" value="91 online" helper="Acceptance, radius, location heartbeat, vehicle compatibility." />
        <OpsPanel icon={TicketCheck} title="Support tickets" value="23 open" helper="Delivery edits, refund checks, business account requests." />
        <OpsPanel icon={AlertTriangle} title="Risk signals" value="7 flags" helper="Fraud structure ready for AI-assisted risk scoring." />
      </div>
    </section>
  );
}

function DriverWithdrawalSection({
  withdrawals,
  busyAction,
  onReview
}: {
  withdrawals: AdminWithdrawal[];
  busyAction: string | null;
  onReview: (id: string, status: "approved" | "rejected" | "paid") => void;
}) {
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between gap-4 border-b border-fleet-line p-5">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-fleet bg-fleet-night text-white">
            <CircleDollarSign className="h-5 w-5" />
          </span>
          <div>
            <h2 className="text-xl font-black text-fleet-night">Driver withdrawal section</h2>
            <span className="text-sm font-bold text-slate-500">Approve, reject with reason, or mark credited</span>
          </div>
        </div>
        <StatusBadge tone="amber">{withdrawals.filter((withdrawal) => withdrawal.status === "pending").length} pending</StatusBadge>
      </div>
      <div className="grid gap-3 p-4">
        {withdrawals.map((withdrawal) => {
          const rider = withdrawal.rider_profiles?.users;
          const driverName = rider?.full_name || withdrawal.account_name || "Driver";
          const canAct = withdrawal.status === "pending";
          return (
            <article key={withdrawal.id} className="rounded-fleet border border-fleet-line bg-white p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <strong className="block text-lg font-black text-fleet-night">{driverName}</strong>
                  <span className="mt-1 block text-xs font-bold leading-5 text-slate-500">
                    {withdrawal.bank_name} · {withdrawal.account_number} · {withdrawal.account_name || "No account name"}
                  </span>
                  <span className="mt-1 block text-xs font-bold leading-5 text-slate-500">
                    KYC: {withdrawal.rider_profiles?.application_status || "unknown"} · Zone: {withdrawal.rider_profiles?.operating_zone || "not set"}
                  </span>
                </div>
                <div className="text-left sm:text-right">
                  <strong className="block text-2xl font-black text-fleet-night">{formatMoney(Number(withdrawal.amount_ngn || 0))}</strong>
                  <StatusBadge tone={withdrawal.status === "approved" || withdrawal.status === "paid" ? "green" : withdrawal.status === "rejected" ? "red" : "amber"}>
                    {withdrawal.status}
                  </StatusBadge>
                </div>
              </div>
              {withdrawal.rejection_reason ? (
                <div className="mt-3 rounded-fleet bg-rose-50 p-3 text-xs font-bold leading-5 text-rose-700">{withdrawal.rejection_reason}</div>
              ) : null}
              <div className="mt-4 grid gap-2 sm:grid-cols-3">
                <Button
                  type="button"
                  size="sm"
                  onClick={() => onReview(withdrawal.id, "approved")}
                  disabled={!canAct || busyAction === `withdrawal:${withdrawal.id}:approved`}
                >
                  Approve
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="secondary"
                  onClick={() => onReview(withdrawal.id, "rejected")}
                  disabled={!canAct || busyAction === `withdrawal:${withdrawal.id}:rejected`}
                >
                  Reject
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="dark"
                  onClick={() => onReview(withdrawal.id, "paid")}
                  disabled={withdrawal.status !== "approved" || busyAction === `withdrawal:${withdrawal.id}:paid`}
                >
                  Mark paid
                </Button>
              </div>
            </article>
          );
        })}
      </div>
    </Card>
  );
}

function AdminTable({
  icon: Icon,
  title,
  subtitle,
  rows,
  actions
}: {
  icon: LucideIcon;
  title: string;
  subtitle: string;
  rows: string[][];
  actions: string[];
}) {
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between gap-4 border-b border-fleet-line p-5">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-fleet bg-fleet-night text-white">
            <Icon className="h-5 w-5" />
          </span>
          <div>
            <h2 className="text-xl font-black text-fleet-night">{title}</h2>
            <span className="text-sm font-bold text-slate-500">{subtitle}</span>
          </div>
        </div>
        <Button type="button" size="sm" variant="secondary">
          Export
        </Button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <tbody>
            {rows.map((row) => (
              <tr key={row.join("-")} className="border-b border-fleet-line last:border-0">
                {row.map((cell, index) => (
                  <td key={cell} className="px-5 py-4 font-bold text-slate-600">
                    {index === row.length - 1 ? <StatusBadge tone={cell.includes("approved") ? "green" : "amber"}>{cell}</StatusBadge> : cell}
                  </td>
                ))}
                <td className="px-5 py-4">
                  <div className="flex gap-2">
                    {actions.slice(0, 2).map((action) => (
                      <Button key={action} type="button" size="sm" variant={action === "Approve" ? "primary" : "secondary"}>
                        {action}
                      </Button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function OpsPanel({ icon: Icon, title, value, helper }: { icon: LucideIcon; title: string; value: string; helper: string }) {
  return (
    <Card className="p-5">
      <Icon className="h-5 w-5 text-fleet-ember" />
      <strong className="mt-4 block text-3xl font-black text-fleet-night">{value}</strong>
      <h3 className="mt-2 text-lg font-black text-fleet-night">{title}</h3>
      <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{helper}</p>
    </Card>
  );
}

function AdminInput({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="form-field">
      <span className="form-label">{label}</span>
      <input className="form-input" value={value} onChange={(event) => onChange(event.target.value)} inputMode="decimal" />
    </label>
  );
}
