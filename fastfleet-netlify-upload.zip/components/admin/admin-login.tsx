"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";

export function AdminLogin() {
  const router = useRouter();
  const [username, setUsername] = useState("FastFleetAdmin");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function signIn() {
    setLoading(true);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Admin login failed.");
      router.refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Admin login failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="section-wrap grid min-h-[72vh] place-items-center py-10">
      <Card className="w-full max-w-xl p-5 sm:p-7">
        <div className="flex items-start justify-between gap-4">
          <div>
            <StatusBadge tone="blue">Private admin</StatusBadge>
            <h1 className="mt-4 text-3xl font-black leading-tight text-fleet-night sm:text-4xl">FastFleet admin access</h1>
            <p className="mt-3 text-sm font-semibold leading-6 text-slate-600">
              Use the dedicated admin credentials. This is separate from customer and driver registration.
            </p>
          </div>
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-fleet bg-fleet-night text-white">
            <LockKeyhole className="h-5 w-5" />
          </span>
        </div>

        <div className="mt-6 grid gap-4">
          <label className="form-field">
            <span className="form-label">Username</span>
            <input className="form-input" value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" />
          </label>
          <label className="form-field">
            <span className="form-label">Password</span>
            <input
              className="form-input"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              type="password"
              autoComplete="current-password"
            />
          </label>
        </div>

        {message ? <div className="mt-5 rounded-fleet bg-rose-50 p-3 text-sm font-bold text-rose-700">{message}</div> : null}

        <Button type="button" className="mt-6 w-full" onClick={signIn} disabled={loading || !username.trim() || !password.trim()}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <LockKeyhole className="h-4 w-4" />}
          Enter admin
        </Button>
      </Card>
    </section>
  );
}
