"use client";

import { useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Bike, Loader2, ShieldCheck, Smartphone, UserRound } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { normalizeRole, roleHome } from "@/lib/auth/roles";
import { NIGERIAN_STATES } from "@/lib/launch-states";
import type { UserRole } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";

const roleOptions: Array<{
  role: UserRole;
  label: string;
  body: string;
  icon: LucideIcon;
}> = [
  {
    role: "customer",
    label: "Continue as Customer",
    body: "Book deliveries, track orders, manage wallet, addresses, receipts, and support.",
    icon: UserRound
  },
  {
    role: "rider",
    label: "Become a Delivery Partner",
    body: "Apply, upload documents, receive jobs, manage earnings, and request withdrawals.",
    icon: Bike
  }
];

export function PhoneAuthForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const returnTo = searchParams.get("returnTo");
  const [step, setStep] = useState<"phone" | "verify">("phone");
  const [role, setRole] = useState<UserRole>("customer");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [state, setState] = useState("Lagos");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const canSubmitPhone = useMemo(
    () => phone.trim().length >= 10 && fullName.trim().length >= 2 && email.trim().includes("@") && state.trim().length > 0,
    [phone, fullName, email, state]
  );

  async function sendOtp() {
    setLoading(true);
    setMessage(null);
    try {
      const supabase = createClient();
      const result = await supabase.auth.signInWithOtp({
        phone: phone.trim(),
        options: {
          shouldCreateUser: true,
          data: {
            role,
            account_type: role,
            full_name: fullName.trim(),
            email: email.trim(),
            state,
            default_zone: state,
            launch_state: state
          }
        }
      });

      if (result.error) throw result.error;
      setStep("verify");
      setMessage("OTP sent. Enter the code from your phone to continue.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not send OTP. Check your Supabase phone provider settings.");
    } finally {
      setLoading(false);
    }
  }

  async function verifyOtp() {
    setLoading(true);
    setMessage(null);
    try {
      const supabase = createClient();
      const result = await supabase.auth.verifyOtp({
        phone: phone.trim(),
        token: otp.trim(),
        type: "sms"
      });

      if (result.error) throw result.error;
      const userRole = normalizeRole(result.data.user?.user_metadata?.role || role);

      if (result.data.user) {
        await supabase.from("users").upsert({
          id: result.data.user.id,
          full_name: fullName.trim(),
          phone: phone.trim(),
          email: email.trim() || result.data.user.email || null,
          role: userRole,
          default_zone: state,
          updated_at: new Date().toISOString()
        });
      }

      router.replace(returnTo || roleHome[userRole]);
      router.refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "OTP verification failed.");
    } finally {
      setLoading(false);
    }
  }

  async function signOut() {
    setLoading(true);
    try {
      const supabase = createClient();
      await supabase.auth.signOut();
      router.refresh();
      setMessage("Signed out.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not sign out.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="p-4 sm:p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <StatusBadge tone="blue">Phone OTP</StatusBadge>
          <h1 className="mt-3 text-3xl font-black leading-tight text-fleet-night sm:text-4xl">Secure FastFleet access</h1>
          <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
            Sessions persist through Supabase Auth cookies and the middleware protects customer, rider, and admin routes.
          </p>
        </div>
        <span className="hidden h-12 w-12 place-items-center rounded-fleet bg-fleet-night text-white sm:grid">
          <ShieldCheck className="h-5 w-5" />
        </span>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {roleOptions.map((option) => {
          const Icon = option.icon;
          const selected = role === option.role;

          return (
            <button
              key={option.role}
              type="button"
              className={`rounded-fleet border p-4 text-left transition ${
                selected ? "border-fleet-ember bg-orange-50 shadow-lift" : "border-fleet-line bg-white hover:border-fleet-gold"
              }`}
              onClick={() => setRole(option.role)}
            >
              <Icon className={selected ? "h-5 w-5 text-fleet-ember" : "h-5 w-5 text-fleet-night"} />
              <strong className="mt-4 block text-sm font-black text-fleet-night">{option.label}</strong>
              <span className="mt-2 block text-xs font-semibold leading-5 text-slate-600">{option.body}</span>
            </button>
          );
        })}
      </div>

      <div className="mt-6 grid gap-4">
        <label className="form-field">
          <span className="form-label">Full name</span>
          <input className="form-input" value={fullName} onChange={(event) => setFullName(event.target.value)} placeholder="Adewale Johnson" autoComplete="name" />
        </label>
        <label className="form-field">
          <span className="form-label">Phone number</span>
          <input className="form-input" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="+2348012345678" autoComplete="tel" inputMode="tel" />
        </label>
        <label className="form-field">
          <span className="form-label">Email</span>
          <input className="form-input" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" autoComplete="email" inputMode="email" />
        </label>
        <label className="form-field">
          <span className="form-label">State</span>
          <select className="form-input" value={state} onChange={(event) => setState(event.target.value)}>
            {NIGERIAN_STATES.map((stateOption) => (
              <option key={stateOption} value={stateOption}>
                {stateOption}
              </option>
            ))}
          </select>
        </label>

        {step === "verify" ? (
          <label className="form-field">
            <span className="form-label">OTP code</span>
            <input className="form-input text-center text-xl tracking-[0.4em]" value={otp} onChange={(event) => setOtp(event.target.value)} placeholder="000000" inputMode="numeric" maxLength={6} />
          </label>
        ) : null}
      </div>

      {message ? (
        <div className="mt-5 rounded-fleet border border-amber-200 bg-amber-50 p-3 text-sm font-bold leading-6 text-amber-800">
          {message}
        </div>
      ) : null}

      <div className="mt-6 grid gap-3 sm:grid-cols-[1fr_auto]">
        {step === "phone" ? (
          <Button type="button" disabled={!canSubmitPhone || loading} onClick={sendOtp}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Smartphone className="h-4 w-4" />}
            Send OTP
          </Button>
        ) : (
          <Button type="button" disabled={otp.trim().length < 4 || loading} onClick={verifyOtp}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
            Verify and continue
          </Button>
        )}
        <Button type="button" variant="secondary" onClick={signOut} disabled={loading}>
          Logout
        </Button>
      </div>
    </Card>
  );
}
