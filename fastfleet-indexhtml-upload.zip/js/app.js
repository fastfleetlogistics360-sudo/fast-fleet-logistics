(function () {
  "use strict";

  var CONFIG = window.FASTFLEET_SUPABASE || {};
  var TABLES = {
    orders: CONFIG.ordersTable || "delivery_orders",
    profiles: CONFIG.profilesTable || "user_profiles"
  };
  var supabaseClient = null;
  var mapRegistry = {};

  var STORAGE = {
    session: "fastfleet.session",
    profiles: "fastfleet.profiles",
    orders: "fastfleet.orders",
    riders: "fastfleet.riders",
    tickets: "fastfleet.tickets"
  };

  var STATUS_FLOW = [
    "Order received",
    "Courier assigned",
    "Picked up",
    "In transit",
    "Delivered"
  ];

  var COURIERS = [
    { name: "Tunde A.", vehicle: "Motorbike", rating: "4.94", phone: "+234 801 220 4410" },
    { name: "Amara N.", vehicle: "Car", rating: "4.91", phone: "+234 809 117 3320" },
    { name: "Kelvin O.", vehicle: "Van", rating: "4.88", phone: "+234 806 551 0921" },
    { name: "Seyi B.", vehicle: "Box truck", rating: "4.96", phone: "+234 810 456 7712" }
  ];

  function ready(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  function hasSupabaseConfig() {
    return Boolean(
      window.supabase &&
      CONFIG.url &&
      CONFIG.anonKey &&
      CONFIG.url.indexOf("YOUR_") === -1 &&
      CONFIG.anonKey.indexOf("YOUR_") === -1
    );
  }

  function client() {
    if (!hasSupabaseConfig()) return null;
    if (!supabaseClient) {
      supabaseClient = window.supabase.createClient(CONFIG.url, CONFIG.anonKey);
    }
    return supabaseClient;
  }

  function readJson(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function textFromForm(form, name) {
    var field = form.elements[name];
    return field ? String(field.value || "").trim() : "";
  }

  function selectedValue(form, name) {
    var checked = form.querySelector('input[name="' + name + '"]:checked');
    if (checked) return checked.value;
    return textFromForm(form, name);
  }

  function simpleHash(text) {
    var hash = 0;
    var str = String(text || "");
    for (var i = 0; i < str.length; i += 1) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash);
  }

  function formatMoney(value) {
    var amount = Math.max(0, Math.round(Number(value) || 0));
    return "NGN " + amount.toLocaleString("en-NG");
  }

  function formatDate(value) {
    if (!value) return "Today";
    try {
      return new Intl.DateTimeFormat("en-NG", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }).format(new Date(value));
    } catch (error) {
      return String(value);
    }
  }

  function makeOrderCode() {
    var tail = Date.now().toString().slice(-6);
    var suffix = Math.floor(10 + Math.random() * 90);
    return "FFL-" + tail + "-" + suffix;
  }

  function vehicleLabel(value) {
    return {
      bike: "Motorbike",
      car: "Car",
      van: "Delivery van",
      truck: "Box truck"
    }[value] || "Motorbike";
  }

  function speedLabel(value) {
    return {
      standard: "Standard",
      express: "Express",
      priority: "Priority"
    }[value] || "Standard";
  }

  function statusClass(status) {
    if (status === "Delivered") return "green";
    if (status === "In transit" || status === "Picked up") return "orange";
    return "";
  }

  function estimateDelivery(input) {
    var pickup = input.pickup || "";
    var dropoff = input.dropoff || "";
    var vehicle = input.vehicle || "bike";
    var speed = input.speed || "standard";
    var seed = simpleHash(pickup + "|" + dropoff + "|" + vehicle);
    var distance = Math.max(2.4, Math.round(((seed % 290) / 10 + 3.2) * 10) / 10);
    var base = { bike: 1800, car: 3200, van: 6500, truck: 12000 }[vehicle] || 1800;
    var perKm = { bike: 220, car: 320, van: 520, truck: 880 }[vehicle] || 220;
    var multiplier = { standard: 1, express: 1.28, priority: 1.68 }[speed] || 1;
    var price = (base + distance * perKm) * multiplier;
    var minutes = Math.round((distance / (vehicle === "bike" ? 28 : 22)) * 60 + (speed === "standard" ? 28 : 14));

    return {
      distance: distance,
      price: Math.round(price / 50) * 50,
      eta: Math.max(18, minutes)
    };
  }

  function courierFor(order) {
    var list = COURIERS.filter(function (courier) {
      if (order.vehicle_type === "bike") return courier.vehicle === "Motorbike";
      if (order.vehicle_type === "car") return courier.vehicle === "Car";
      if (order.vehicle_type === "van") return courier.vehicle === "Van";
      if (order.vehicle_type === "truck") return courier.vehicle === "Box truck";
      return true;
    });
    var candidates = list.length ? list : COURIERS;
    return candidates[simpleHash(order.order_code || order.pickup_address) % candidates.length];
  }

  function sampleOrder() {
    var order = {
      order_code: "FFL-DEMO-1001",
      customer_name: "Demo customer",
      customer_phone: "+234 800 000 0000",
      recipient_name: "Recipient",
      recipient_phone: "+234 800 111 1111",
      pickup_address: "Victoria Island, Lagos",
      dropoff_address: "Ikeja GRA, Lagos",
      package_type: "Retail parcel",
      vehicle_type: "bike",
      delivery_speed: "express",
      payment_method: "card",
      distance_km: 22.4,
      price_ngn: 10850,
      status: "In transit",
      created_at: new Date().toISOString()
    };
    var courier = courierFor(order);
    order.courier_name = courier.name;
    order.courier_phone = courier.phone;
    return order;
  }

  async function getSession() {
    var c = client();
    if (c) {
      try {
        var result = await c.auth.getSession();
        if (result.data && result.data.session) return result.data.session;
      } catch (error) {
        showToast("Supabase session check failed. Demo session is still available.", "error");
      }
    }
    return readJson(STORAGE.session, null);
  }

  function localSessionFrom(profile) {
    return {
      access_token: "local-demo-session",
      user: {
        id: "local-" + simpleHash(profile.email),
        email: profile.email,
        user_metadata: {
          full_name: profile.full_name || profile.email,
          phone: profile.phone || "",
          account_type: profile.account_type || "customer"
        }
      }
    };
  }

  async function signUp(profile) {
    var c = client();
    if (c) {
      var result = await c.auth.signUp({
        email: profile.email,
        password: profile.password,
        options: {
          data: {
            full_name: profile.full_name,
            phone: profile.phone,
            account_type: profile.account_type
          }
        }
      });
      if (result.error) throw result.error;
      if (result.data && result.data.session) {
        await upsertProfile(result.data.session.user, profile);
      }
      return result.data;
    }

    var profiles = readJson(STORAGE.profiles, {});
    profiles[profile.email] = {
      full_name: profile.full_name,
      phone: profile.phone,
      account_type: profile.account_type,
      email: profile.email
    };
    writeJson(STORAGE.profiles, profiles);
    writeJson(STORAGE.session, localSessionFrom(profile));
    return { session: readJson(STORAGE.session, null) };
  }

  async function signIn(credentials) {
    var c = client();
    if (c) {
      var result = await c.auth.signInWithPassword({
        email: credentials.email,
        password: credentials.password
      });
      if (result.error) throw result.error;
      return result.data;
    }

    var profiles = readJson(STORAGE.profiles, {});
    var profile = profiles[credentials.email] || {
      full_name: credentials.email.split("@")[0],
      phone: "",
      account_type: "customer",
      email: credentials.email
    };
    writeJson(STORAGE.session, localSessionFrom(profile));
    return { session: readJson(STORAGE.session, null) };
  }

  async function signOut() {
    var c = client();
    if (c) {
      await c.auth.signOut();
    }
    localStorage.removeItem(STORAGE.session);
    await updateAuthUi();
    showToast("Signed out.");
  }

  async function upsertProfile(user, profile) {
    var c = client();
    if (!c || !user) return;
    try {
      await c.from(TABLES.profiles).upsert({
        id: user.id,
        email: user.email,
        full_name: profile.full_name,
        phone: profile.phone,
        account_type: profile.account_type,
        updated_at: new Date().toISOString()
      });
    } catch (error) {
      // The app still works if the optional profile table has not been created yet.
    }
  }

  async function saveOrder(order) {
    var session = await getSession();
    var user = session && session.user;
    var c = client();
    var payload = Object.assign({}, order, {
      user_id: user ? user.id : null,
      user_email: user ? user.email : "",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    if (c && user) {
      try {
        var result = await c.from(TABLES.orders).insert(payload).select().single();
        if (result.error) throw result.error;
        return result.data;
      } catch (error) {
        showToast("Saved locally. Run the Supabase schema to sync orders online.", "error");
      }
    }

    var orders = readJson(STORAGE.orders, []);
    orders.unshift(payload);
    writeJson(STORAGE.orders, orders);
    return payload;
  }

  async function fetchOrders() {
    var session = await getSession();
    var user = session && session.user;
    var c = client();
    if (c && user) {
      try {
        var result = await c
          .from(TABLES.orders)
          .select("*")
          .order("created_at", { ascending: false })
          .limit(100);
        if (result.error) throw result.error;
        return result.data || [];
      } catch (error) {
        showToast("Could not load Supabase orders. Showing local orders.", "error");
      }
    }

    var all = readJson(STORAGE.orders, []);
    if (!user) return all;
    return all.filter(function (order) {
      return order.user_email === user.email || order.user_id === user.id;
    });
  }

  async function findOrder(code) {
    var normalized = String(code || "").trim().toUpperCase();
    if (!normalized) return null;
    var c = client();
    if (c) {
      try {
        var result = await c
          .from(TABLES.orders)
          .select("*")
          .eq("order_code", normalized)
          .maybeSingle();
        if (result.error) throw result.error;
        if (result.data) return result.data;
      } catch (error) {
        showToast("Could not search Supabase. Checking local orders.", "error");
      }
    }
    return readJson(STORAGE.orders, []).find(function (order) {
      return String(order.order_code).toUpperCase() === normalized;
    }) || null;
  }

  function showToast(message, type) {
    var region = document.querySelector("[data-toast-region]");
    if (!region) {
      region = document.createElement("div");
      region.className = "toast-region";
      region.setAttribute("data-toast-region", "");
      document.body.appendChild(region);
    }
    var toast = document.createElement("div");
    toast.className = "toast" + (type ? " " + type : "");
    toast.textContent = message;
    region.appendChild(toast);
    window.setTimeout(function () {
      toast.remove();
    }, 4300);
  }

  async function updateAuthUi() {
    var session = await getSession();
    var user = session && session.user;
    var name = user && user.user_metadata && user.user_metadata.full_name
      ? user.user_metadata.full_name
      : user && user.email
        ? user.email.split("@")[0]
        : "";

    document.querySelectorAll("[data-auth-signed-in]").forEach(function (el) {
      el.hidden = !user;
    });
    document.querySelectorAll("[data-auth-signed-out]").forEach(function (el) {
      el.hidden = Boolean(user);
    });
    document.querySelectorAll("[data-user-name]").forEach(function (el) {
      el.textContent = name || "Account";
    });
    document.querySelectorAll("[data-supabase-mode]").forEach(function (el) {
      el.textContent = hasSupabaseConfig()
        ? "Supabase connected. Accounts and orders will sync to your project."
        : "Demo mode is active. Add your Supabase URL and anon key in js/supabase-config.js to enable live accounts.";
    });
  }

  function initNavigation() {
    var current = (location.pathname.split("/").pop() || "index.html").toLowerCase();
    document.querySelectorAll(".nav-links a, .mobile-panel a").forEach(function (link) {
      var href = (link.getAttribute("href") || "").split("#")[0].toLowerCase();
      if ((current === "" && href === "index.html") || href === current) {
        link.classList.add("is-active");
      }
    });

    var toggle = document.querySelector("[data-mobile-toggle]");
    var panel = document.querySelector("[data-mobile-panel]");
    if (toggle && panel) {
      toggle.addEventListener("click", function () {
        panel.classList.toggle("is-open");
      });
      panel.querySelectorAll("a").forEach(function (link) {
        link.addEventListener("click", function () {
          panel.classList.remove("is-open");
        });
      });
    }

    document.querySelectorAll("[data-sign-out]").forEach(function (button) {
      button.addEventListener("click", function () {
        signOut();
      });
    });
  }

  function initHeroAdSlider() {
    var root = document.querySelector("[data-ad-hero]");
    if (!root) return;

    var slides = Array.prototype.slice.call(root.querySelectorAll("[data-ad-slide]"));
    var dots = Array.prototype.slice.call(root.querySelectorAll("[data-ad-dot]"));
    var copy = root.querySelector("[data-ad-copy]");
    var eyebrow = root.querySelector("[data-ad-eyebrow]");
    var title = root.querySelector("[data-ad-title]");
    var body = root.querySelector("[data-ad-body]");
    var active = 0;
    var ads = [
      {
        eyebrow: "FastFleet for customers",
        title: "Send parcels across Lagos with calm, visible <span>control.</span>",
        body: "Book bike, car, and van deliveries with live status, trusted riders, and clear customer updates."
      },
      {
        eyebrow: "Same-day dispatch",
        title: "From pickup request to doorstep handoff, beautifully <span>tracked.</span>",
        body: "Built for retail vendors, offices, food dispatch, pharmacy runs, and urgent city movement."
      },
      {
        eyebrow: "Earn with your vehicle",
        title: "Own a bike, car, or van? Turn it into delivery <span>income.</span>",
        body: "Vehicle owners and delivery partners can apply, upload documents, get reviewed, and start receiving jobs."
      },
      {
        eyebrow: "Business logistics",
        title: "A polished dispatch layer for vendors and fleet <span>operators.</span>",
        body: "Saved addresses, scheduled routes, wallet records, support tickets, rider monitoring, and admin controls."
      },
      {
        eyebrow: "Trusted rider network",
        title: "Premium logistics for Lagos and Ogun State <span>movement.</span>",
        body: "Zone-based dispatch, rider approval workflows, realtime locations, and support built for scale."
      }
    ];

    function render(index) {
      active = index;
      slides.forEach(function (slide, slideIndex) {
        slide.classList.toggle("is-active", slideIndex === active);
      });
      dots.forEach(function (dot, dotIndex) {
        dot.classList.toggle("is-active", dotIndex === active);
      });
      if (copy) {
        copy.classList.remove("is-switching");
        void copy.offsetWidth;
        copy.classList.add("is-switching");
      }
      if (eyebrow) eyebrow.textContent = ads[active].eyebrow;
      if (title) title.innerHTML = ads[active].title;
      if (body) body.textContent = ads[active].body;
    }

    dots.forEach(function (dot, index) {
      dot.addEventListener("click", function () {
        render(index);
      });
    });

    window.setInterval(function () {
      render((active + 1) % ads.length);
    }, 6200);
  }

  function initAuthPage() {
    var tabs = document.querySelectorAll("[data-auth-tab]");
    if (!tabs.length) return;

    tabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        var target = tab.getAttribute("data-auth-tab");
        tabs.forEach(function (item) {
          item.classList.toggle("is-active", item === tab);
        });
        document.querySelectorAll("[data-auth-form]").forEach(function (form) {
          form.classList.toggle("is-active", form.getAttribute("data-auth-form") === target);
        });
      });
    });

    var returnTo = new URLSearchParams(location.search).get("return") || "dashboard.html";

    document.querySelectorAll("[data-auth-form]").forEach(function (form) {
      form.addEventListener("submit", async function (event) {
        event.preventDefault();
        var mode = form.getAttribute("data-auth-form");
        try {
          if (mode === "signin") {
            await signIn({
              email: textFromForm(form, "email"),
              password: textFromForm(form, "password")
            });
            showToast("Welcome back.", "success");
            window.setTimeout(function () { location.href = returnTo; }, 650);
          } else {
            var result = await signUp({
              full_name: textFromForm(form, "full_name"),
              phone: textFromForm(form, "phone"),
              email: textFromForm(form, "email"),
              password: textFromForm(form, "password"),
              account_type: textFromForm(form, "account_type") || "customer"
            });
            await updateAuthUi();
            if (result && result.session) {
              showToast("Account created.", "success");
              window.setTimeout(function () { location.href = returnTo; }, 650);
            } else {
              showToast("Account created. Check your email if confirmation is enabled.", "success");
            }
          }
        } catch (error) {
          showToast(error.message || "Authentication failed.", "error");
        }
      });
    });
  }

  function prefillOrderForm(form) {
    var params = new URLSearchParams(location.search);
    ["pickup", "dropoff", "vehicle", "speed"].forEach(function (name) {
      if (!params.has(name)) return;
      var field = form.elements[name];
      if (field) field.value = params.get(name);
    });
  }

  function initOrderPage() {
    var form = document.querySelector("[data-order-form]");
    if (!form) return;
    prefillOrderForm(form);

    var priceNode = document.querySelector("[data-order-price]");
    var distanceNode = document.querySelector("[data-order-distance]");
    var etaNode = document.querySelector("[data-order-eta]");
    var vehicleNode = document.querySelector("[data-order-vehicle]");
    var courierNode = document.querySelector("[data-courier-preview]");

    function currentEstimate() {
      return estimateDelivery({
        pickup: textFromForm(form, "pickup"),
        dropoff: textFromForm(form, "dropoff"),
        vehicle: selectedValue(form, "vehicle"),
        speed: selectedValue(form, "speed")
      });
    }

    function renderEstimate() {
      var estimate = currentEstimate();
      if (priceNode) priceNode.textContent = formatMoney(estimate.price);
      if (distanceNode) distanceNode.textContent = estimate.distance + " km";
      if (etaNode) etaNode.textContent = estimate.eta + " min";
      if (vehicleNode) vehicleNode.textContent = vehicleLabel(selectedValue(form, "vehicle"));
      if (courierNode) {
        var previewOrder = {
          order_code: textFromForm(form, "pickup") + textFromForm(form, "dropoff"),
          vehicle_type: selectedValue(form, "vehicle"),
          pickup_address: textFromForm(form, "pickup")
        };
        var courier = courierFor(previewOrder);
        courierNode.innerHTML =
          '<strong>' + escapeHtml(courier.name) + '</strong>' +
          '<span>' + escapeHtml(courier.vehicle) + ' nearby, rated ' + escapeHtml(courier.rating) + '</span>';
      }
      return estimate;
    }

    form.addEventListener("input", renderEstimate);
    form.addEventListener("change", renderEstimate);
    renderEstimate();

    form.addEventListener("submit", async function (event) {
      event.preventDefault();
      var session = await getSession();
      if (!session || !session.user) {
        showToast("Create an account or sign in before placing a delivery.", "error");
        window.setTimeout(function () {
          location.href = "auth.html?return=order.html";
        }, 800);
        return;
      }

      var estimate = currentEstimate();
      var order = {
        order_code: makeOrderCode(),
        customer_name: textFromForm(form, "customer_name"),
        customer_phone: textFromForm(form, "customer_phone"),
        recipient_name: textFromForm(form, "recipient_name"),
        recipient_phone: textFromForm(form, "recipient_phone"),
        pickup_address: textFromForm(form, "pickup"),
        dropoff_address: textFromForm(form, "dropoff"),
        pickup_note: textFromForm(form, "pickup_note"),
        package_type: textFromForm(form, "package_type"),
        vehicle_type: selectedValue(form, "vehicle"),
        delivery_speed: selectedValue(form, "speed"),
        payment_method: textFromForm(form, "payment_method"),
        distance_km: estimate.distance,
        price_ngn: estimate.price,
        eta_minutes: estimate.eta,
        status: "Courier assigned"
      };
      var courier = courierFor(order);
      order.courier_name = courier.name;
      order.courier_phone = courier.phone;

      try {
        var saved = await saveOrder(order);
        showToast("Delivery order received. Courier assigned.", "success");
        window.setTimeout(function () {
          location.href = "track.html?code=" + encodeURIComponent(saved.order_code);
        }, 750);
      } catch (error) {
        showToast(error.message || "Could not place order.", "error");
      }
    });
  }

  function initUseLocationButtons() {
    document.querySelectorAll("[data-use-location]").forEach(function (button) {
      button.addEventListener("click", function () {
        var targetName = button.getAttribute("data-use-location");
        var target = document.querySelector('[name="' + targetName + '"]');
        if (!navigator.geolocation) {
          showToast("Location is not available in this browser.", "error");
          return;
        }
        button.disabled = true;
        button.textContent = "Locating...";
        navigator.geolocation.getCurrentPosition(function (position) {
          var lat = position.coords.latitude.toFixed(5);
          var lng = position.coords.longitude.toFixed(5);
          if (target) {
            target.value = "Current location (" + lat + ", " + lng + ")";
            target.dispatchEvent(new Event("input", { bubbles: true }));
          }
          updateMapToLocation(lat, lng);
          button.disabled = false;
          button.textContent = "Use my location";
          showToast("Pickup location added.", "success");
        }, function () {
          button.disabled = false;
          button.textContent = "Use my location";
          showToast("Location permission was not granted.", "error");
        }, { enableHighAccuracy: true, timeout: 10000 });
      });
    });
  }

  function mapFallback(element, label) {
    if (!element || element.querySelector(".map-fallback")) return;
    element.innerHTML =
      '<div class="map-fallback">' +
        '<div class="fallback-route"></div>' +
        '<span class="fallback-pin start"></span>' +
        '<span class="fallback-driver">FF</span>' +
        '<span class="fallback-pin end"></span>' +
        '<div class="map-caption">' +
          '<strong>' + escapeHtml(label || "Live delivery map") + '</strong>' +
          '<span>Pickup, courier and drop-off route preview.</span>' +
        '</div>' +
      '</div>';
  }

  function initMaps() {
    document.querySelectorAll(".js-map").forEach(function (element) {
      var label = element.getAttribute("data-map-label") || "FastFleet route";
      if (!window.L) {
        mapFallback(element, label);
        return;
      }

      var center = [6.5244, 3.3792];
      var map = window.L.map(element, {
        zoomControl: false,
        attributionControl: false
      }).setView(center, 12);
      window.L.control.zoom({ position: "bottomright" }).addTo(map);
      window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19
      }).addTo(map);

      var start = center;
      var end = [6.6018, 3.3515];
      var middle = [6.557, 3.397];
      var route = window.L.polyline([start, middle, end], {
        color: "#ff6a00",
        weight: 5,
        opacity: 0.86
      }).addTo(map);
      window.L.marker(start).addTo(map).bindPopup("Pickup");
      window.L.marker(middle).addTo(map).bindPopup("Courier nearby");
      window.L.marker(end).addTo(map).bindPopup("Drop-off");
      map.fitBounds(route.getBounds(), { padding: [28, 28] });

      mapRegistry[element.id || element.getAttribute("data-map-id") || "map"] = {
        map: map,
        route: route
      };
    });
  }

  function updateMapToLocation(lat, lng) {
    Object.keys(mapRegistry).forEach(function (key) {
      var item = mapRegistry[key];
      var start = [Number(lat), Number(lng)];
      var end = [Number(lat) + 0.045, Number(lng) + 0.05];
      var middle = [Number(lat) + 0.024, Number(lng) + 0.015];
      item.map.setView(start, 13);
      item.route.setLatLngs([start, middle, end]);
    });
  }

  function timelineHtml(order) {
    var index = Math.max(0, STATUS_FLOW.indexOf(order.status || "Order received"));
    return STATUS_FLOW.map(function (status, statusIndex) {
      var done = statusIndex < index;
      var current = statusIndex === index;
      var cls = done ? " is-done" : current ? " is-current" : "";
      var hint = {
        "Order received": "FastFleet has received the delivery request.",
        "Courier assigned": "A verified courier has accepted the order.",
        "Picked up": "The package has been collected from pickup.",
        "In transit": "The courier is heading to the destination.",
        "Delivered": "The recipient has confirmed delivery."
      }[status];
      return '' +
        '<div class="timeline-step' + cls + '">' +
          '<div class="timeline-rail"><span class="timeline-dot"></span></div>' +
          '<div class="timeline-content"><strong>' + status + '</strong><span>' + hint + '</span></div>' +
        '</div>';
    }).join("");
  }

  function orderCardHtml(order) {
    return '' +
      '<article class="order-card">' +
        '<header>' +
          '<div><strong>' + escapeHtml(order.order_code) + '</strong><div class="route-pair"><span>' + escapeHtml(formatDate(order.created_at)) + '</span></div></div>' +
          '<span class="status-pill ' + statusClass(order.status) + '">' + escapeHtml(order.status || "Order received") + '</span>' +
        '</header>' +
        '<div class="route-pair">' +
          '<div><span>Pickup</span>' + escapeHtml(order.pickup_address) + '</div>' +
          '<div><span>Drop-off</span>' + escapeHtml(order.dropoff_address) + '</div>' +
        '</div>' +
        '<div class="list-row">' +
          '<span>' + escapeHtml(vehicleLabel(order.vehicle_type)) + ' / ' + escapeHtml(speedLabel(order.delivery_speed)) + '</span>' +
          '<strong>' + formatMoney(order.price_ngn) + '</strong>' +
        '</div>' +
        '<a class="button secondary small" href="track.html?code=' + encodeURIComponent(order.order_code) + '">Track order <span aria-hidden="true">-></span></a>' +
      '</article>';
  }

  async function initDashboard() {
    var list = document.querySelector("[data-dashboard-orders]");
    if (!list) return;
    var session = await getSession();
    var gate = document.querySelector("[data-dashboard-gate]");
    if (!session || !session.user) {
      if (gate) gate.hidden = false;
      list.innerHTML = '<div class="empty-state">Sign in to see your deliveries, receipts and live status.</div>';
      return;
    }
    if (gate) gate.hidden = true;
    var orders = await fetchOrders();
    if (!orders.length) {
      list.innerHTML = '<div class="empty-state">No delivery orders yet. Place your first dispatch request to see it here.</div>';
    } else {
      list.innerHTML = orders.map(orderCardHtml).join("");
    }

    var active = orders.filter(function (order) {
      return order.status !== "Delivered";
    }).length;
    var totalSpend = orders.reduce(function (sum, order) {
      return sum + (Number(order.price_ngn) || 0);
    }, 0);

    setText("[data-stat-orders]", orders.length);
    setText("[data-stat-active]", active);
    setText("[data-stat-spend]", formatMoney(totalSpend));
  }

  async function initTrackPage() {
    var form = document.querySelector("[data-track-form]");
    var details = document.querySelector("[data-track-details]");
    if (!form || !details) return;

    async function render(code, allowSample) {
      var order = code ? await findOrder(code) : null;
      if (!order && allowSample) order = sampleOrder();
      if (!order) {
        details.innerHTML = '<div class="empty-state">No delivery found for that tracking code.</div>';
        return;
      }
      details.innerHTML =
        '<div class="panel pad">' +
          '<div class="panel-head">' +
            '<div><span class="kicker">Tracking code</span><h2>' + escapeHtml(order.order_code) + '</h2></div>' +
            '<span class="status-pill ' + statusClass(order.status) + '">' + escapeHtml(order.status || "Order received") + '</span>' +
          '</div>' +
          '<div class="route-pair">' +
            '<div><span>Pickup</span>' + escapeHtml(order.pickup_address) + '</div>' +
            '<div><span>Drop-off</span>' + escapeHtml(order.dropoff_address) + '</div>' +
          '</div>' +
          '<div class="quote-box">' +
            '<div class="quote-row"><span>Courier</span><strong>' + escapeHtml(order.courier_name || courierFor(order).name) + '</strong></div>' +
            '<div class="quote-row"><span>Phone</span><strong>' + escapeHtml(order.courier_phone || courierFor(order).phone) + '</strong></div>' +
            '<div class="quote-row"><span>Vehicle</span><strong>' + escapeHtml(vehicleLabel(order.vehicle_type)) + '</strong></div>' +
            '<div class="quote-row"><span>Fee</span><strong>' + formatMoney(order.price_ngn) + '</strong></div>' +
          '</div>' +
        '</div>' +
        '<div class="panel pad"><h3>Delivery timeline</h3><div class="timeline">' + timelineHtml(order) + '</div></div>';
    }

    var params = new URLSearchParams(location.search);
    var initial = params.get("code");
    form.elements.code.value = initial || "";
    await render(initial, true);

    form.addEventListener("submit", async function (event) {
      event.preventDefault();
      await render(textFromForm(form, "code"), false);
    });
  }

  function setText(selector, value) {
    var node = document.querySelector(selector);
    if (node) node.textContent = value;
  }

  function initSimpleStorageForm(selector, storageKey, message) {
    var form = document.querySelector(selector);
    if (!form) return;
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var payload = {};
      Array.prototype.slice.call(form.elements).forEach(function (field) {
        if (field.name) payload[field.name] = field.value;
      });
      payload.created_at = new Date().toISOString();
      var rows = readJson(storageKey, []);
      rows.unshift(payload);
      writeJson(storageKey, rows);
      form.reset();
      showToast(message, "success");
    });
  }

  ready(function () {
    initNavigation();
    initHeroAdSlider();
    initAuthPage();
    initOrderPage();
    initUseLocationButtons();
    initMaps();
    initDashboard();
    initTrackPage();
    initSimpleStorageForm("[data-rider-form]", STORAGE.riders, "Rider application received.");
    initSimpleStorageForm("[data-support-form]", STORAGE.tickets, "Support request received.");
    updateAuthUi();

    var c = client();
    if (c) {
      c.auth.onAuthStateChange(function () {
        updateAuthUi();
      });
    }
  });

  window.FastFleet = {
    signOut: signOut,
    showToast: showToast
  };
})();
