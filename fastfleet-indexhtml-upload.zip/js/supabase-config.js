window.FASTFLEET_SUPABASE = {
  url: "YOUR_SUPABASE_PROJECT_URL",
  anonKey: "YOUR_SUPABASE_ANON_KEY",
  profilesTable: "user_profiles",
  ordersTable: "delivery_orders"
};
